﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion("1.8.0.0")]
[assembly: AssemblyTitle("ModCheck")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ModCheck")]
[assembly: AssemblyCopyright("Copyright ©  2017-2018")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("796a79a2-6754-4847-9910-28de0a4e5ff1")]
[assembly: AssemblyFileVersion("1.8.0.0")]
